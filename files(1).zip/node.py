"""
node.py – Bindet alles zusammen
================================

Startet einen Knoten im verteilten Chat-System.
Verbindet: LCRNode (Wahl) + HeartbeatMonitor (Überwachung)
           + ChatServer (nur Leader) + DiscoveryListener (nur Leader)

Ablauf:
  1. UUID generieren
  2. LCR-Ring mit bekannten Knoten aufbauen
  3. Wahl starten → wer gewinnt, wird Leader
  4. Leader startet: ChatServer + DiscoveryListener
  5. Follower starten: HeartbeatMonitor (überwacht Leader)
  6. Fällt Leader aus → neue Wahl

Verwendung:
  python node.py --ip 127.0.0.1 --peers 127.0.0.2 127.0.0.3
"""

import threading
import time
import argparse

# ── Eigene Module importieren ────────────────────────────────────
from lcr        import LCRNode, generate_uid
from heartbeat  import HeartbeatMonitor
from server     import ChatServer
from discovery  import DiscoveryListener

CHAT_PORT = 5000  # Port auf dem der ChatServer läuft (nur beim Leader)


class Node:
    """
    Ein vollständiger Knoten im verteilten Chat-System.

    Verbindet LCR-Wahl, Heartbeat, ChatServer und Discovery
    zu einem einzigen startbaren Objekt.
    """

    def __init__(self, my_ip: str, peer_ips: list[str]):
        self.my_ip    = my_ip
        self.my_uid   = generate_uid()  # Zufällige UUID – Best Practice laut Prof

        # ── Mitgliederliste aufbauen ──────────────────────────────
        # Format: [{"uid": "...", "ip": "..."}]
        # Eigene UID kennen wir, die der Peers noch nicht → Platzhalter
        # (werden nach JOIN-Handshake aktualisiert – vereinfacht hier als direkte Liste)
        self._members = [{"uid": self.my_uid, "ip": my_ip}]
        for ip in peer_ips:
            # Peers bekommen temporäre UIDs – werden nach erster Wahl aktualisiert
            self._members.append({"uid": ip, "ip": ip})  # IP als temporäre UID

        # ── Komponenten erstellen ─────────────────────────────────
        self._lcr = LCRNode(
            my_uid           = self.my_uid,
            my_ip            = self.my_ip,
            members          = self._members,
            on_leader_elected= self._on_leader_elected,  # Callback wenn Wahl fertig
        )

        self._heartbeat = HeartbeatMonitor(
            my_ip      = self.my_ip,
            on_timeout = self._on_leader_timeout,  # Callback wenn Leader ausfällt
        )

        # ChatServer + DiscoveryListener – werden nur gestartet wenn ich Leader bin
        self._chat_server  = ChatServer(host=self.my_ip, port=CHAT_PORT)
        self._discovery    = DiscoveryListener(my_ip=self.my_ip, chat_port=CHAT_PORT)
        self._server_thread = None

    # ══════════════════════════════════════════════════════════════
    # START – Knoten starten
    # ══════════════════════════════════════════════════════════════
    def start(self):
        print(f"\n{'='*60}")
        print(f"  Knoten startet")
        print(f"  UUID : {self.my_uid}")
        print(f"  IP   : {self.my_ip}")
        print(f"  Peers: {[m['ip'] for m in self._members if m['ip'] != self.my_ip]}")
        print(f"{'='*60}\n")

        # LCR-Ring-Socket starten + Empfangs-Thread
        self._lcr.start()

        # Kurz warten damit alle Knoten ihren Socket geöffnet haben
        time.sleep(1)

        # Wahl anstoßen
        self._lcr.initiate_election()

    # ══════════════════════════════════════════════════════════════
    # CALLBACK: Wahl abgeschlossen
    # Wird von LCRNode aufgerufen sobald ein Leader feststeht
    # ══════════════════════════════════════════════════════════════
    def _on_leader_elected(self, leader_uid: str):
        am_leader = (leader_uid == self.my_uid)

        print(f"\n[NODE] Wahl abgeschlossen.")
        print(f"[NODE] Leader UUID : {leader_uid[:8]}…")
        print(f"[NODE] Ich bin Leader: {am_leader}\n")

        if am_leader:
            # ── ICH BIN LEADER ────────────────────────────────────
            # 1. ChatServer starten (in eigenem Thread, da blocking)
            self._server_thread = threading.Thread(
                target=self._chat_server.start,
                daemon=True,
                name="chat-server"
            )
            self._server_thread.start()
            print(f"[NODE] ChatServer gestartet auf {self.my_ip}:{CHAT_PORT}")

            # 2. Discovery-Listener starten → Clients können mich jetzt finden
            self._discovery.start()

            # 3. Heartbeat als Leader senden
            self._heartbeat.start(is_leader=True, members=self._members)

        else:
            # ── ICH BIN FOLLOWER ──────────────────────────────────
            # Heartbeat-Monitor starten → überwacht ob Leader noch lebt
            self._heartbeat.start(is_leader=False, members=self._members)

    # ══════════════════════════════════════════════════════════════
    # CALLBACK: Leader ausgefallen
    # Wird von HeartbeatMonitor aufgerufen wenn Leader nicht antwortet
    # ══════════════════════════════════════════════════════════════
    def _on_leader_timeout(self):
        print("\n[NODE] Leader ausgefallen! Starte neue Wahl …\n")

        # Discovery-Listener stoppen (nur aktiv wenn ich Leader war)
        self._discovery.stop()

        # Neue Wahl anstoßen
        self._lcr.initiate_election()


# ══════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Chat-System Knoten")
    parser.add_argument("--ip",    required=True,          help="Eigene IP-Adresse")
    parser.add_argument("--peers", nargs="*", default=[],  help="IPs der anderen Knoten")
    args = parser.parse_args()

    node = Node(my_ip=args.ip, peer_ips=args.peers)
    node.start()

    # Hauptthread am Leben halten
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[NODE] Knoten wird beendet.")
